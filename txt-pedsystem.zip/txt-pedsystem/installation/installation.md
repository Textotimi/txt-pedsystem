# txt-pedsytem installation guide

This guide will provide step-by-step instructions on how to install and set up the txt-pedsystem script for FiveM. This script requires the es_extendet/qb_core to be installed and running on your server.

# Step 1:
After downloading the script, unzip the folder and place it in the `resources` directory on your FiveM server. Make sure to also install `Badger_Discord_API`

# Step 2:
Setup the script of your liking in the `configuration` file in `config.lua`

# Step 3:
Add your Discord bot token and your Discord guild_id into the `Badger_Discord_API`

# Step 4:
Add `ensure txt-pedsystem` and `ensure Badger_Discord_API` into your server.cfg

# ALL DONE
Enjoy your work and the script