Thanks for getting txt-pedsystem

Do not forget to look into installation folder and finish the installation guide!
