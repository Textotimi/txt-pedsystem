game 'gta5'

author 'txt-scripts'
description 'Smooth ped system for your FiveM server'

fx_version 'cerulean'

shared_scripts {
    'config.lua',
}

client_scripts {
	'client.lua',
}

server_scripts {
	'server.lua'
}
