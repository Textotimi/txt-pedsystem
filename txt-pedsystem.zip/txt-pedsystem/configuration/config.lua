Config = {}
Config.Permissions = true -- if set to false, everyone can use the command (default true)

Config.Allowed = {
}

Config.PedData = {
    {
      title = 'Westy',
      description = 'Chose this ped',
      event = 'bbv-switchped',
      args = {
        ped = 'a_c_westy'
      }
    }
}